/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package view;

import model.Cliente;
import model.Producto;
import model.ProductoVenta;
import model.Venta;

/**
 *
 * @author ASUS
 */
public class Demo {
     public static void main(String[] args) {
        Cliente Cliente1;
        Producto producto1;
        Producto producto2;
        Venta venta1;

        ProductoVenta productoVenta;

        Cliente1 = new Cliente("1044", "Alvaro", "Alvarez", "Masculino");

        producto1 = new Producto("Computador", 2000000, 10, 20);
        producto2 = new Producto("Celular",    1500000, 8,  10);
       // new Producto("Cargador", 100000, 2, 50);

        venta1 = new Venta(Cliente1);
        productoVenta = new ProductoVenta(producto1, 6);
        venta1.agregarProducto(productoVenta);
        productoVenta = new ProductoVenta(producto2, 3);
        
        

        venta1.agregarProducto(productoVenta);
        
        venta1.imprimir();
        System.out.println("hola");
    }

}
