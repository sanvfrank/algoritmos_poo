/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class Cliente {
    
    private String identificacion;
    private String nombre;
    private String apellido;
    private String genero;

    public Cliente() {

    }

    public Cliente(String identificacion, String nombre, String apellido, String genero) {
        setIdentificacion(identificacion);
        setNombre(nombre);
        setApellido(apellido);
        setGenero(genero);
    }

    public String getIdentificacion() {
        return identificacion;
    }

    public void setIdentificacion(String identificacion) {
        if (identificacion == null) {
            throw new IllegalArgumentException("Identificacion no puede ser nulo");
        }
        this.identificacion = identificacion;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre == null) {
            throw new IllegalArgumentException("Nombre no puede ser nulo");
        }
        this.nombre = nombre;
    }

    public String getApellido() {
        return apellido;
    }

    public void setApellido(String apellido) {
        if (apellido == null) {
            throw new IllegalArgumentException("Apellido no puede ser nulo");
        }
        this.apellido = apellido;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        if (genero == null) {
            throw new IllegalArgumentException("Genero no puede ser nulo");
        }
        if (!genero.matches("Masculino|Femenino")) {
            throw new IllegalArgumentException("Genero debe ser Masculino o"
                    + "Femenino");
        }
        this.genero = genero;
    }

    @Override
    public String toString() {
        return identificacion + " - " + nombre + " " + apellido;
    }

}
