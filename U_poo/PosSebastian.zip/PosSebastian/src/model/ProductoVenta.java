/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class ProductoVenta {
     private Producto producto;
    private int cantidad;

    public ProductoVenta() {
        setProducto(new Producto());
        setCantidad(0);
    }

    public ProductoVenta(Producto producto, int cantidad) {
        setProducto(producto);
        setCantidad(cantidad);
    }

    public Producto getProducto() {
        return producto;
    }

    public void setProducto(Producto producto) {
        if (producto == null) {
            throw new IllegalArgumentException("Producto no puede ser nulo");
        }
        this.producto = producto;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        if (cantidad < 0) {
            throw new IllegalArgumentException("cantidad no puede ser negativo");
        }
        this.cantidad = cantidad;
    }

    public double subtotalizar() {
        return getProducto().calcularPrecioConIva() * getCantidad();
        
    }

    public void disminuirStock() {
        getProducto().setStock(getProducto().getStock() - getCantidad());
        
    }

    @Override
    public String toString() {

        return producto + "\t" + cantidad + "\t" + String.format("%10.0f", subtotalizar());
    }

}
