/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import java.time.LocalDate;
import java.util.ArrayList;

/**
 *
 * @author ASUS
 */
public class Venta {
     private static int consecutivo;
    private int codigo;
    private LocalDate fecha;
    private Cliente cliente;
    private ArrayList<ProductoVenta> listaProducto;

    public Venta() {
    }

    public Venta(Cliente cliente) {
        setCodigo(++consecutivo);
        setFecha(LocalDate.now());
        setCliente(cliente);
        setListaProducto(new ArrayList());
    }

    public Venta(int codigo, LocalDate fecha, Cliente cliente, ArrayList<ProductoVenta> listaProducto) {
        setListaProducto(listaProducto);
        setFecha(fecha);
        setCliente(cliente);
        setCodigo(codigo);
    }

    public ArrayList<ProductoVenta> getListaProducto() {
        return listaProducto;
    }

    public void setListaProducto(ArrayList<ProductoVenta> listaProducto) {
        this.listaProducto = listaProducto;
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if (codigo < 0) {
            throw new IllegalArgumentException("Codigo no puede ser negativo");
        }
        this.codigo = codigo;
    }

    public LocalDate getFecha() {
        return fecha;
    }

    public void setFecha(LocalDate fecha) {
        if (fecha == null) {
            throw new IllegalArgumentException("Fecha no puede ser nula");
        }
        this.fecha = fecha;
    }

    public Cliente getCliente() {
        return cliente;
    }

    public void setCliente(Cliente cliente) {
        if (cliente == null) {
            throw new IllegalArgumentException("Cliente no puede ser nulo");
        }
        this.cliente = cliente;
    }

    public void agregarProducto(ProductoVenta productoVenta) {
        if (productoVenta == null) {
            throw new IllegalArgumentException("productoventa"
                    + " no puede ser nulo");
        }
        if (productoVenta.getCantidad()
                > productoVenta.getProducto().getStock()) {
            throw new IllegalArgumentException("Stock no disponible");
        }

        listaProducto.add(productoVenta);
        productoVenta.disminuirStock();
    }

    public void agregarProducto(Producto producto, int cantidad) {
        ProductoVenta productoVenta;
        productoVenta = new ProductoVenta(producto, cantidad);
        agregarProducto(productoVenta);
    }

    public void agregarProducto(Producto producto) {
        agregarProducto(producto, 1);

    }

    public void agregarProducto(Producto... productos) {
        for (Producto producto : productos) {
            agregarProducto(producto);
        }
    }

    public double totalizar() {
        double total;
        total = 0;
        for (ProductoVenta productoVenta : listaProducto) {
            total += productoVenta.subtotalizar();
        }
        return total;
    }

    @Override
    public String toString() {
        return codigo + " fecha= " + fecha + ", cliente= " + cliente;
    }

    public void imprimir() {

        for (ProductoVenta productoVenta : listaProducto) {
            System.out.println(productoVenta);
        }
        System.out.println("Total:" + "\t"
                + String.format("%10.0f", totalizar()));
    }

    
        }
    


