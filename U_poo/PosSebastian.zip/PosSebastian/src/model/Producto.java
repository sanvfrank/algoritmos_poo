/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author ASUS
 */
public class Producto {
     private static int consecutivo;
    private int codigo;
    private String descripcion;
    private double precio;
    private double Iva;
    private int Stock;

    public Producto() {
        setCodigo(0);
        setDescripcion("SIN ASIGNAR");
        setPrecio(0);

    }

    public Producto(int codigo, String descripcion, double precio) {
        setCodigo(codigo);
        setDescripcion(descripcion);
        setPrecio(precio);
    }

    public Producto(String descripcion, double precio) {
        this(++consecutivo, descripcion, precio);
    }

    public Producto(int codigo, String descripcion, double precio, double Iva, int Stock) {
        setCodigo(codigo);
        setDescripcion(descripcion);
        setPrecio(precio);
        setIva(Iva);
        setStock(Stock);
    }

    public Producto(String descripcion, double precio, double Iva, int Stock) {
        this(++consecutivo, descripcion, precio, Iva, Stock);
    }

    public int getCodigo() {
        return codigo;
    }

    public void setCodigo(int codigo) {
        if (codigo < 0) {
            throw new IllegalArgumentException("Codigo no puede ser negativo");
        }
        this.codigo = codigo;
    }

    public String getDescripcion() {
        return descripcion;
    }

    public void setDescripcion(String descripcion) {
        if (descripcion == null) {
            throw new IllegalArgumentException("La descripcion no puede ser nula");
        }
        this.descripcion = descripcion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        if (precio < 0) {
            throw new IllegalArgumentException("Precio no puede ser negativo");
        }
        this.precio = precio;
    }

    public double getIva() {
        return Iva;
    }

    public void setIva(double Iva) {
        if (Iva < 0) {
            throw new IllegalArgumentException("Iva no puede ser negativo");
        }
        this.Iva = Iva;
    }

    public double calcularPrecioConIva() {
        return getPrecio() * (1 + getIva() / 100);
    }

    public int getStock() {
        return Stock;
    }

    public void setStock(int Stock) {
        if (Stock < 0) {
            throw new IllegalArgumentException("Stock no puede ser negativo");
        }
        this.Stock = Stock;
    }

    @Override
    public String toString() {
        return codigo + ":" + descripcion + " "
                + "\t" + String.format("%10.0f", precio)
                + String.format("%10.0f", Iva) + "%"
                + String.format("%10.0f", calcularPrecioConIva());
    }

}
